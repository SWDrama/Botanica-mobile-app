onEvent("Sign_up_Welcome", "click", function() {
  setScreen("Sign_Up_Page");
});
onEvent("Log_In_Welcome", "click", function( ) {
  setScreen("Login_Page");
});

//SignUp code
var firstname = "";
var secondname = "";
var email = "";
var password = "";

onEvent("Sign_Up_SignPage", "click", function( ) {
  firstname = getProperty("Input_Name", "value");
  secondname = getProperty("Input_Surname", "value");
  email = getProperty("Input_Email", "value");
  password = getProperty("Input_Password", "value");
  
  if (firstname !== "" && secondname !== "" && email !== "" && password !== "") {
    createRecord("Accounts", {FirstName:firstname, SecondName:secondname, Email:email, Password:password},  function() {
      
    });
    setText("Input_Name", "");
    setText("Input_Surname", "");
    setText("Input_Email", "");
    setText("Input_Password", "");
  setScreen("Home_Page");
  }
  else {
    setText("Error_Label", "Incorrect Name or Password.");
    setTimeout(function(){
      setText("Error_Label", "");
      
    }, 3000);
  }
  
});
// Login code
var emailLog = "";
var passLog = "";
var currentuser = "";
onEvent("LoginB_Login", "click", function( ) {
  emailLog = getProperty("Email_Input_Login", "value");
  passLog = getProperty("Pass_Input_Login", "value");
  currentuser = getText("Email_Input_Login");
  
readRecords("Accounts", {}, function(records) {
    for (var i =0; i < records.length; i++) {
  emailLog = getText("Email_Input_Login");
  passLog = getText("Pass_Input_Login");
   if (getText ("Email_Input_Login")== records [i].Email){
     //&& getText ("Pass_Input_Login")== records [i].Password

    if (getText ("Pass_Input_Login")== records [i].Password){
     currentuser = getText("Email_Input_Login");
     setScreen("Home_Page"); 
  }
   else {
    setText("Error_Login_Label", "Incorrect Email or Password.");
    setText("Email_Input_Login", "");
    setText("Pass_Input_Login", "");
    setTimeout(function(){
      setText("Error_Login_Label", "");
      
    }, 3000);
    }
    }
  }
});
});

//---------
// SOME of the VARIABLES USED
var Dropdown_TreatType = "";
var Treatment_Name = "";
//---------

////Event plus function for dropdown treatment type and treatment
onEvent ("Dropdown_Treat0", "change", function() {
  Dropdown_TreatType = "Dropdown_Treat0";
  TreatmentsPage(Dropdown_TreatType);
});

function TreatmentsPage() {
  if (getText(Dropdown_TreatType) == "Hair Treatments") {
    showElement("Dropdown_Hair_Treat");
    hideElement("Dropdown_Barber_Treat");
    hideElement("Dropdown_Beauty_Treat");
    
}
  else if (getText(Dropdown_TreatType) == "Beauty Treatments") {
    showElement("Dropdown_Beauty_Treat");
    hideElement("Dropdown_Hair_Treat");
    hideElement("Dropdown_Barber_Treat");
  }
  else if (getText(Dropdown_TreatType) == "Barber Treatments") {
    showElement("Dropdown_Barber_Treat");
    hideElement("Dropdown_Beauty_Treat");
    hideElement("Dropdown_Hair_Treat");
  }
}

//On event function for date/time dropdowns to appear
onEvent ("Dropdown_Hair_Treat", "change", function() {
  if (getText("Dropdown_Hair_Treat")!== ""){
    showElement("Available_Dates_Drop");
    showElement("Available_Times_Drop");
    Treatment_Name = getText("Dropdown_Hair_Treat");
  }
});

onEvent ("Dropdown_Beauty_Treat", "change", function() {
  if (getText("Dropdown_Beauty_Treat")!== ""){
    showElement("Available_Dates_Drop");
    showElement("Available_Times_Drop");
    Treatment_Name = getText("Dropdown_Beauty_Treat");
  }
});

onEvent ("Dropdown_Barber_Treat", "change", function() {
  if (getText("Dropdown_Barber_Treat")!== ""){
    showElement("Available_Dates_Drop");
    showElement("Available_Times_Drop");
    Treatment_Name = getText("Dropdown_Barber_Treat");
  }
});

onEvent ("Available_Times_Drop", "change", function() {
  if (getText("Available_Times_Drop")!== ""){
    showElement("BookB_Treat");
  }
});

//Date input for bookings. Reads the data from the table
readRecords("Dates", {}, function(records) {
  var datesList = [];
  for (var i =0; i < records.length; i++) {
    appendItem(datesList, records[i].date);
  }
  setProperty("Available_Dates_Drop","options", datesList);
});

//Time input for bookings. Reads the data from the table
readRecords("Times", {}, function(records) {
  var TimesList = [];
  for (var i =0; i < records.length; i++) {
    appendItem(TimesList, records[i].Time);
  }
  setProperty("Available_Times_Drop","options", TimesList);
});

//To store the treatment booking with date and time in the table
onEvent("BookB_Treat", "click", function( ) {
  var booking = {};
  booking.Treatment = Treatment_Name;
  booking.Datess = getText("Available_Dates_Drop");
  booking.Timess = getText("Available_Times_Drop");
  booking.Username = currentuser;
  createRecord("Booked", booking, function() {
    
    console.log("record is created: ");
  
  });
  setScreen("Home_Page");
});

//PROFILE information pulling from table
onEvent("Profile_B", "click", function( ) {
  setScreen("Profile_Page");
  setText("Email_area",currentuser);
  readRecords("Accounts", {}, function(records){
    if (records.length>0){
      for(var i = 0; i < records.length; i++){
      if (currentuser == records[i].Email) {
        setText("FirstName_area", records[i]. FirstName);
        setText("Surname_area", records[i]. SecondName);
        setText("Email_area", currentuser);
      }
      }
      }
});
});
      
//NAV BAR BUTTON History check
onEvent("History_B", "click", function( ) {
  setScreen("History");
  var Booking_History = "";
  readRecords("Booked", {Username:currentuser}, function(records){
    if (records.length>0){
      for(var i = 0; i < records.length; i++){
        Booking_History += records[i].Treatment + " " + records[i].Datess + " " + records[i].Timess + "\n";
      }
      setText("History_area", Booking_History);
    }else{
      write("No bookings yet");
    }
  });
});

onEvent("HistoryB_Treat0", "click", function( ) {
  setScreen("History");
  var Booking_History = "";
  readRecords("Booked", {}, function(records){
    if (records.length>0){
      for(var i = 0; i < records.length; i++){
        Booking_History += records[i].Treatment + " " + records[i].Datess + " " + records[i].Timess + "\n";
      }
      setText("History_area", Booking_History);
    }else{
      write("No bookings yet");
    }
  });
});

onEvent("HistoryB_HistoryP", "click", function( ) {
  setScreen("History");
  var Booking_History = "";
  readRecords("Booked", {}, function(records){
    if (records.length>0){
      for(var i = 0; i < records.length; i++){
        Booking_History += records[i].Treatment + " " + records[i].Datess + " " + records[i].Timess + "\n";
      }
      setText("History_area", Booking_History);
    }else{
      write("No bookings yet");
    }
  });
});

onEvent("HistoryB_ProfileP", "click", function( ) {
  setScreen("History");
  var Booking_History = "";
  readRecords("Booked", {}, function(records){
    if (records.length>0){
      for(var i = 0; i < records.length; i++){
        Booking_History += records[i].Treatment + " " + records[i].Datess + " " + records[i].Timess + "\n";
      }
      setText("History_area", Booking_History);
    }else{
      write("No bookings yet");
    }
  });
});

//NAV BAR BUTTON Home Page-----
onEvent("Home_B", "click", function( ) {
  setScreen("Home_Page");
});
onEvent("HomeB_ProfileP", "click", function( ) {
  setScreen("Home_Page");
});
onEvent("HomeB_Treat0", "click", function( ) {
  setScreen("Home_Page");
});
onEvent("HomeB_HistoryP", "click", function( ) {
  setScreen("Home_Page");
});

//NAV BAR BUTTON Profile-----
onEvent("Profile_B", "click", function( ) {
  setScreen("Profile_Page");
});
onEvent("ProfileB_HistoryP", "click", function( ) {
  setScreen("Profile_Page");
});
onEvent("ProfileB_Treat0", "click", function( ) {
  setScreen("Profile_Page");
});
onEvent("ProfileB_ProfileP", "click", function( ) {
  setScreen("Profile_Page");
});

//NAV BAR BUTTON Booking-----
onEvent("Bookings_B", "click", function( ) {
  setScreen("treatments0");
});
onEvent("BookB_Treat0", "click", function( ) {
  setScreen("treatments0");
});
onEvent("BookingsB_HistoryP", "click", function( ) {
  setScreen("treatments0");
});
onEvent("BookingB_ProfileP", "click", function( ) {
  setScreen("treatments0");
});




//TRY BUTTONS
//onEvent("Tryy1", "click", function( ) {
//	setScreen("treatments0");
//});
//onEvent("tryy2", "click", function( ) {
//	setScreen("Home_Page");
//});
/////

//onEvent("TreatmentsB", "click", function( ) {
//	setScreen("treatments0");
//});
